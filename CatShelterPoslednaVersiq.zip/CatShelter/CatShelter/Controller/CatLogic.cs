﻿using CatShelter.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatShelter.Controller
{
    public class CatLogic
    {
        private CatsContext _catsContext = new CatsContext();
        public Animal Get(int id)
        {

            Animal foundCat = _catsContext.Animals.Find(id);
            if (foundCat != null)
            {
                _catsContext.Entry(foundCat).Reference(x => x.Breeds).Load();
            }
            return foundCat;
        }

        public List<Animal> GetAll()
        {
            return _catsContext.Animals.Include("Breeds").ToList();
        }

        public void Create(Animal animal)
        {
            _catsContext.Animals.Add(animal);
            _catsContext.SaveChanges();
        }

        public void Update(int id, Animal animal)
        {
            Animal foundCat = _catsContext.Animals.Find(id);
            if (foundCat == null)
            {
                return;
            }
            foundCat.Age = animal.Age;
            foundCat.Name = animal.Name;
            foundCat.Description = animal.Description;
            foundCat.BreedId = animal.BreedId;
            _catsContext.SaveChanges();
        }

        public void Delete(int id)
        {
            Animal foundCat = _catsContext.Animals.Find(id);
            _catsContext.Animals.Remove(foundCat);
            _catsContext.SaveChanges();
        }
    }
}

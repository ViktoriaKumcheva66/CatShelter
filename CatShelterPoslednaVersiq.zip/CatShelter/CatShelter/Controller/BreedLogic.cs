﻿using CatShelter.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatShelter.Controller
{
    public class BreedLogic
    {
        private CatsContext _catsContext = new CatsContext();
        public List<Breed> GetAllBreeds()
        {
            return _catsContext.Breeds.ToList();
        }
        public string GetBreedById(int Id)
        {
            return _catsContext.Breeds.Find(Id).BreedName;
        }
    }
}

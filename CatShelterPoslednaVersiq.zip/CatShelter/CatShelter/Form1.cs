﻿using CatShelter.Controller;
using CatShelter.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CatShelter
{
    public partial class Form1 : Form
    {
        CatLogic catController = new CatLogic();
        BreedLogic breedController = new BreedLogic();
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadRecord(Animal Animal)
        {
            textBox1.BackColor = Color.White;
            textBox1.Text = Animal.Id.ToString();
            textBox2.Text = Animal.Name;
            textBox3.Text = Animal.Description;
            textBox4.Text = Animal.Age.ToString();
            comboBox1.Text = Animal.Breeds.BreedName;
        }
        private void ClearScreen()
        {
            textBox1.BackColor = Color.White;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            comboBox1.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Breed> allBreeds = breedController.GetAllBreeds();
            comboBox1.DataSource = allBreeds;
            comboBox1.DisplayMember = "BreedName";
            comboBox1.ValueMember = "Id";
            btnSelectAll_Click(sender, e);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text == "")
            {
                MessageBox.Show("Въведете данни!");
                textBox2.Focus();
                return;
            }
            Animal newCat = new Animal();
            newCat.Age = int.Parse(textBox4.Text);
            newCat.Name = textBox2.Text;
            newCat.BreedId = (int)comboBox1.SelectedValue;
            newCat.Description = textBox3.Text;
            catController.Create(newCat);
            MessageBox.Show("Записът е успешно добавен!");
            ClearScreen();
            btnSelectAll_Click(sender, e);
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            List<Animal> allCats = catController.GetAll();
            listBox1.Items.Clear();
            foreach (var item in allCats)
            {
                listBox1.Items.Add($"{item.Id}. {item.Name},  {item.Description} Age: {item.Age} Breed: {item.Breeds.BreedName}");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int findId = 0;
            if (string.IsNullOrEmpty(textBox1.Text) || !textBox1.Text.All(char.IsDigit))
            {
                MessageBox.Show("Въведете Id за ърсене!");
                textBox1.BackColor = Color.Red;
                textBox1.Focus();
                return;
            }
            else
            {
                findId = int.Parse(textBox1.Text);
            }
            Animal foundCat = catController.Get(findId);
            if (foundCat == null)
            {
                MessageBox.Show("НЯМА ТАКЪВ ЗАПИС в БД! \n Въведете Id за търсене!");
                textBox1.BackColor = Color.Red;
                textBox1.Focus();
                return;
            }
            LoadRecord(foundCat);
            DialogResult answer = MessageBox.Show("Наистина ли искате да изтриете запис № " +
            findId + " ?",
            "PROMPT", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                catController.Delete(findId);
            }
            btnSelectAll_Click(sender, e);
        }

        private void btnUpd_Click(object sender, EventArgs e)
        {
            int findId = 0;
            if (string.IsNullOrEmpty(textBox1.Text) || !textBox1.Text.All(char.IsDigit))
            {
                MessageBox.Show("Въведете Id за търсене!");
                textBox1.BackColor = Color.Red;
                textBox1.Focus();
                return;
            }
            else
            {
                findId = int.Parse(textBox1.Text);
            }
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                Animal foundCat = catController.Get(findId);
                if (foundCat == null)
                {
                    MessageBox.Show("НЯМА ТАКЪВ ЗАПИС в БД! \n Въведете Id за търсене!");
                    textBox1.BackColor = Color.Red;
                    textBox1.Focus();
                    return;
                }
                LoadRecord(foundCat);
            }
            else
            {
                Animal updateCat = new Animal();
                updateCat.Name = textBox2.Text;
                updateCat.Description = textBox3.Text;
                updateCat.Age = int.Parse(textBox4.Text);
                updateCat.BreedId = (int)comboBox1.SelectedValue;
                catController.Update(findId, updateCat);
            }
            btnSelectAll_Click(sender, e);
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            int findId = 0;
            if (string.IsNullOrEmpty(textBox1.Text) || !textBox1.Text.All(char.IsDigit))
            {
                MessageBox.Show("Въведете Id за търсене!");
                textBox1.BackColor = Color.Red;
                textBox1.Focus();
                return;
            }
            else
            {
                findId = int.Parse(textBox1.Text);
            }
            Animal foundCat = catController.Get(findId);
            if (foundCat == null)
            {
                MessageBox.Show("НЯМА ТАКЪВ ЗАПИС в БД! \n Въведете Id за търсене!");
                textBox1.BackColor = Color.Red;
                textBox1.Focus();
                return;
            }
            LoadRecord(foundCat);
        }
    }
}
